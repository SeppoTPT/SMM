#include "simulation/ElementCommon.h"

static int update(UPDATE_FUNC_ARGS);
static int graphics(GRAPHICS_FUNC_ARGS);

void Element::Element_GASO()
{
	Identifier = "DEFAULT_PT_GASO";
	Name = "GASO";
	Colour = PIXPACK(0xFFFF60);
	MenuVisible = 1;
	MenuSection = SC_GAS;
	Enabled = 1;

	Advection = 0.4f;
	AirDrag = 0.01f * CFDS;
	AirLoss = 0.99f;
	Loss = 0.30f;
	Collision = -0.1f;
	Gravity = 0.4f;
	Diffusion = 0.05f;
	HotAir = 0.001f * CFDS;
	Falldown = 5;

	Flammable = 100;
	Explosive = 1200;
	Meltable = 0;
	Hardness = 5;

	Weight = 8;

	DefaultProperties.temp = R_TEMP + 2.0f + 273.15f;
	HeatConduct = 42;
	Description = "Refined Gasoline, more efficient than GAS. Can be derived from OIL, or KERO";

	Properties = TYPE_LIQUID | PROP_NEUTPASS;

	LowPressure = NT;
	LowPressureTransition = NT;
	HighPressure = 6.0f;
	HighPressureTransition = PT_KERO;
	LowTemperature = ITL;
	LowTemperatureTransition = NT;
	HighTemperature = 873.0f;
	HighTemperatureTransition = PT_FIRE;
}

