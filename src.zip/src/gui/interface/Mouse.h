
#ifdef SDL_INC
#include "SDL2/SDL_mouse.h"
#else
#include "SDL_mouse.h"
#endif
